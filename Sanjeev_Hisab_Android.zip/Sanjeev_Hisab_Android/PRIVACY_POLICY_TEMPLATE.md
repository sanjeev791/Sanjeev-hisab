# Sanjeev Hisab Privacy Policy — Template

**Effective date:** [INSERT DATE]

Sanjeev Hisab is a personal/business ledger app by Sanjeev Kumar. The current offline version stores customer and transaction data locally on the device using app storage. We do not intentionally upload ledger data to our servers in this version.

The app can open WhatsApp or a web browser when you choose to share a statement. The sharing destination is controlled by the apps/services on your device.

If you add analytics, advertising, cloud backup, accounts, payments, crash reporting, or any server-side service later, this policy must be updated before publishing those features.

For privacy questions: [INSERT CONTACT EMAIL]
