# Sanjeev Hisab — Android Studio Project

Brand: Sanjeev Hisab
Owner name shown in app: Sanjeev Kumar
Tagline: हर हिसाब, आसान हिसाब

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync/download Android Gradle Plugin dependencies.
3. For a test APK: Build > Build APK(s).
4. For Play Store: Build > Generate Signed Bundle / APK > Android App Bundle.
5. Create a release keystore and keep it safe. Google Play App Signing is recommended.

Package: com.sanjeevhisab.app
Target SDK: 35
Min SDK: 23
Version: 1.0.0 (versionCode 1)

## WhatsApp
The app sends the complete customer statement from the HTML app to WhatsApp via the device's external URL handler. If WhatsApp is installed, Android opens it; otherwise a browser/handler may be used. The statement includes transactions, totals, balance direction and notes.

## Important before Play Store submission
- Replace the temporary app icon with final production artwork.
- Prepare and host a real privacy policy URL.
- Complete Play Console Data safety and content declarations accurately.
- Test on multiple Android phones and verify WhatsApp, backup/restore, PIN and data persistence.
- Create a signed AAB for upload; do not upload a debug APK.
- Monetization (ads or paid/premium features) needs its own Play Console/AdMob or Play Billing setup and policy review.
