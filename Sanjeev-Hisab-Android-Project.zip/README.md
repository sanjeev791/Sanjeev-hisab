# Sanjeev Hisab — Android App

This project wraps the existing Sanjeev Hisab web app as a proper Android application using Capacitor.

## Build
1. Install Node.js LTS and Android Studio.
2. Run `npm install`.
3. Run `npx cap add android`.
4. Run `npx cap sync android`.
5. Open the `android` folder in Android Studio.
6. For a Play Store release, create a signed Android App Bundle (`.aab`) from Android Studio.

App ID: `com.sanjeevhisab.app`
App name: `Sanjeev Hisab`
